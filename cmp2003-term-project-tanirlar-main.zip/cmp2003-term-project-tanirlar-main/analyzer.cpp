#include "analyzer.h"
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <utility>
using namespace std;

// Students may use ANY data structure internally
map<string, long long> zoneMapCount;
map<pair<string, int>, long long> slotMapCount;
void ingestFile(const std::string& csvPath) {
    // TODO:
    // - open file
    // - skip header
    // - skip malformed rows
    // - extract PickupZoneID and pickup hour
    // - aggregate counts
    ifstream inputFile(csvPath); 
    string line;

    getline(inputFile, line); // skip header
    while (getline(inputFile, line)){
        size_t firstComma = line.find(',');
        if (firstComma == string::npos) continue; //malformed rows
        size_t secondComma = line.find(',', firstComma + 1);
        if (secondComma == string::npos) continue;
        size_t thirdComma = line.find(',', secondComma + 1);
        if (thirdComma == string::npos) continue;
        size_t fourthComma = line.find(',', thirdComma + 1);  //firstComma ve seconComma arası; thirdComma ve fourthComma arasını alcaz
        if (fourthComma == string::npos) continue;

        //extracting zoneID
        string zoneID = line.substr(firstComma + 1, secondComma - firstComma - 1);
        if (zoneID.empty()) continue;

        string dateHour = line.substr(thirdComma + 1, fourthComma - thirdComma -1);
        if (dateHour.size() < 16) continue; //malformed rows
        string pickUpHourString = dateHour.substr(11, 2);
        int pickUpHour = stoi(pickUpHourString);

        pair<string, int> slotKey = {zoneID, pickUpHour}; 
         
        zoneMapCount[zoneID]++; //mapping 
        slotMapCount[slotKey]++;
    }
}

std::vector<ZoneCount> TripAnalyzer::topZones(int k) const {
    // TODO:
    // - sort by count desc, zone asc
    // - return first k
    return {};
}

std::vector<SlotCount> TripAnalyzer::topBusySlots(int k) const {
    // TODO:
    // - sort by count desc, zone asc, hour asc
    // - return first k
    return {};
}



